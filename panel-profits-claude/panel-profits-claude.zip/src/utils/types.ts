export type MarketData = {
  // Define market data types
};

export type TradeOrder = {
  // Define trade order types
};
