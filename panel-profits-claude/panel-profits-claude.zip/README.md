# Panel Profits

A sophisticated comic trading platform with advanced market simulation features.

## Features
- Real-time market data
- Advanced trading instruments
- Portfolio management
- Risk analysis
- Market making capabilities

## Setup
```bash
npm install
npm run dev
