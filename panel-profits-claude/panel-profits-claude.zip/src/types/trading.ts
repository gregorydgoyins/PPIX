export interface Order {
  // Define order interface
}

export interface Trade {
  // Define trade interface
}
