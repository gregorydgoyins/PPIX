import React from 'react';

export const OrderEntry = () => {
  return (
    <div>
      <h2>Order Entry</h2>
      {/* Add order entry components */}
    </div>
  );
};
