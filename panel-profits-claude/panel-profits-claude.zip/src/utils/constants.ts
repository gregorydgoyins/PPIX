export const API_BASE_URL = 'https://api.example.com';
export const DEFAULT_PAGINATION_LIMIT = 20;
