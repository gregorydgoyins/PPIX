export interface Holding {
  // Define holding interface
}

export interface Position {
  // Define position interface
}
