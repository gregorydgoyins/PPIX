export interface Instrument {
  // Define instrument interface
}

export interface Price {
  // Define price interface
}
