import React from 'react';

export const OrderBook = () => {
  return (
    <div>
      <h2>Order Book</h2>
      {/* Add order book component */}
    </div>
  );
};
